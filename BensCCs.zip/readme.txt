Contents of this zip file
BensCCs.nam:  }
BensCCs.opt:  } world files with cc's in to explore
BensCCs.world }

BensCCs.csv: a notepad/spreadsheet readable text file that lists all the CC's with their attributes

BensCCs.dat: a MyWorld character Creator database file
.png files for each of the CCs 
readme.txt: This file

Using my character creations in your own worlds.
================================================
go to Myworld in your steam library. If your steam library is on your C drive then the folder yoiu need will be here:-
C:\Program Files (x86)\Steam\steamapps\common\MyWorld\MyWorld_Data\Resources\user

look for a file called cc.dat. This is your existing Character Creator database. Rename it. I suggest 'Mycc.dat'.
copy everything from the zipped folder to this folder.
rename BensCCs.dat as cc.dat.

That's it. You can now use Myworld and add characters from your new cc.dat to your world.
When you no longer need these free characters, simply rename cc.dat to Bensccs.dat and rename Mycc.dat to cc.dat.
